<div class="containerWidth">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			      <a class="navbar-brand gh" href="#"></a>
			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      <ul class="nav navbar-nav">
			        <li class="dropdown">
						          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">हमारे बारे में<span class="caret"></span></a>
						          <ul class="dropdown-menu">
						            <li><a href="about"> कंपनी प्रोफाइल</a></li>
						            <li><a href="boardOfDirectors">निदेशक मंडल</a></li>
						            <li><a href="contribution">राष्ट्रीय दूरसंचार के लिए अंशदान</a></li>
						             <li><a href="infrastructure1">बुनियादी ढांचा और सुविधा</a></li>
						             <li><a href="organisationChart"> नियमावली</a></li>
						             <li><a href="moreAbout"> आईटीआई के बारे में अधिक</a></li>
                                     <li><a href="financial_information">वित्तीय जानकारी</a></li>

						          </ul>
					</li>
			        <li class="dropdown">
						          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">उत्पाद<span class="caret"></span></a>
						          <ul class="dropdown-menu">
						            <li><a href="gsm">जीएसएम / सीडीएमए</a></li>
						            <li><a href="defence">रक्षा उत्पाद</a></li>
						            <li><a href="diversified">विविध उत्पाद</a></li>
						          </ul>
					</li>
			         <li><a href="services">वित्तीय जानकारी</a></li>
			         <li><a href="Manufacturing">विनिर्माण इकाइयों</a></li>

			           <li class="dropdown">
						          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">विपणन एवं आरओएस<span class="caret"></span></a>
						          <ul class="dropdown-menu">
						            <li><a href="marketing"> कॉर्पोरेट विपणन</a></li>
						            <li><a href="regionalOffices">क्षेत्रीय कार्यालय</a></li>
						            <li><a href="newDelhi">बी.सी. ऑफि‍स</a></li>
						          </ul>
					</li>			       
					<li><a href="research">अनुसंधान और विकास</a></li>
					<div class="menuHide">
					 <ul class="nav navbar-nav">
					 <li><a href="tender">टेंडर/संवि‍दा</a></li>
			          	<li><a href="hr">मानव संसाधन</a></li>
			             <li class="dropdown">
						          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">समाचार और घटनाक्रम <span class="caret"></span></a>
						          <ul class="dropdown-menu">
						            <li><a href="news"> वर्तमान खबर</a></li>
						            <li><a href="newsOne">समाचार संग्रह</a></li>
						          </ul>
						</li>
			            <li><a href="careers">करियर</a></li>
			            <li><a href="rti">सूचना का अधिकार</a></li>
			            <li><a href="vigilance">सतर्कता</a></li>
			            <li><a href="contact">हमसे संपर्क करे</a></li>
			            </ul>
			         </div>
			      </ul>
			    </div><!-- /.navbar-collapse -->
			  </div><!-- /.container-fluid -->
			</nav>
	</div>