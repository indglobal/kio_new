	<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
<div class="containerWidth headerPart">
		<div class="row">
		  <div class="col-md-3">
		  	<a href="index"><img src="images/logo.jpg"></a>
		  </div>
		  <div class="col-md-5 text-center">
			<a href="index"><img src="images/logo1.jpg"></a>
		  </div>
		  <div class="col-md-4 text-right">
		  <br/>
		  	<h4>Language : <a href="javascript:void(0)"><span class="headerFontWeight2"> हिन्दी </span></a></h4>
		  </div>
		</div>
	</div>