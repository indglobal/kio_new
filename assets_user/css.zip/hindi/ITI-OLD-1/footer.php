<div class="containerWidth backgroundFooter">
		<div class="row">
			<div class="col-md-4">
			<p> &copy 2015 ITIL All Rights Reserved </p>
			</div>
			<div class="col-md-8 text-right">
			<ul>
				<li><a href="javascript:void(0)">About Us </a> |</li>
				<li><a href="javascript:void(0)">Tender-Eols</a> |</li>
				<li><a href="javascript:void(0)">Manufacturing Units</a> |</li>
				<li><a href="javascript:void(0)">Marketing ROS</a> |</li>
				<li><a href="javascript:void(0)">R&D</a>|</li>
				<li><a href="javascript:void(0)">Human Resources</a> |</li>
				<li><a href="javascript:void(0)">Careers</a> |</li>
				<li><a href="javascript:void(0)">Right To Information</a> |</li>
				<li><a href="javascript:void(0)">Vigilance</a></li>

			</ul>
			</div>
		</div>
	</div>