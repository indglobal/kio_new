<div class="containerWidth backgroundFooter">
		<div class="row">
			<div class="col-md-4">
			<p> © 2015 आईटीआईएल सभी अधिकार सुरक्षित </p>
			</div>
			<div class="col-md-8 text-right">
			<ul>
				<li><a href="about">हमारे बारे में </a> |</li>
				<li><a href="javascript:void(0)">टेंडर/संवि‍दा</a> |</li>
				<li><a href="about">उत्पाद </a> |</li>
				<li><a href="marketing">विपणन एवं आरओएस </a> |</li>
				<li><a href="r&d">अनुसंधान और विकास</a>|</li>
				<li><a href="hr">मानव संसाधन</a> |</li>
				<li><a href="careers">करियर</a> |</li>
				<li><a href="rti">सूचना का अधिकार</a> |</li>
				<li><a href="vigilance">सतर्कता</a></li>

			</ul>
			</div>
		</div>
	</div>