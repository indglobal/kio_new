		<div class="containerWidth xy">
			<nav class="navbar navbar-default ss">
			  <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			      <a class="navbar-brand" href="#">  </a>
			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      <ul class="nav navbar-nav">
			       
			        <li><a href="http://www.itiltd-india.com/upload/Tender-EOI.html">टेंडर/संवि‍दा</a></li>
			          	<li><a href="hr">मानव संसाधन</a></li>
			             <li class="dropdown">
						          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">समाचार और घटनाक्रम  <span class="caret"></span></a>
						          <ul class="dropdown-menu">
						            <li><a href="news"> वर्तमान खबर</a></li>
						            <li><a href="newsOne">समाचार संग्रह</a></li>
						          </ul>
						</li>
			            <li><a href="careers">करियर</a></li>
			            <li><a href="rti">सूचना का अधिकार</a></li>
			            <li><a href="vigilance">सतर्कता</a></li>
			            <li><a href="contact">हमसे संपर्क करें</a></li>
			      </ul>
			    </div><!-- /.navbar-collapse -->
			  </div><!-- /.container-fluid -->
			</nav>
	</div>